<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if a file was uploaded
    if (isset($_FILES["file"])) {
        $file = $_FILES["file"];
        $uploadDir = "uploads/"; // Ensure this directory exists and is writable
        $uploadFile = $uploadDir . basename($file["name"]);

        // Validate file type (Only allow text files)
        if (pathinfo($uploadFile, PATHINFO_EXTENSION) !== "txt") {
            echo json_encode(["status" => "error", "message" => "Only .txt files are allowed."]);
            exit;
        }

        // Move the uploaded file to the designated directory
        if (move_uploaded_file($file["tmp_name"], $uploadFile)) {
            echo json_encode(["status" => "success", "message" => "File uploaded successfully!", "filename" => basename($file["name"])]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error uploading file."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "No file received!"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method!"]);
}
?>
